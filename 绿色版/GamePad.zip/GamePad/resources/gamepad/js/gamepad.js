﻿/**
  * 版权所有 2012 Google Inc. 保留所有权利。
  *
  * 根据 Apache 许可证 2.0 版（“许可证”）获得许可；
  * 除非遵守许可，否则您不得使用此文件。
  * 您可以在以下网址获取许可证的副本
  *
  * http://www.apache.org/licenses/LICENSE-2.0
  *
  * 除非适用法律要求或书面同意，否则软件
  *根据许可分发是在“原样”基础上分发的，
  * 不提供任何明示或暗示的保证或条件。
  * 请参阅许可证以了解特定语言的管理权限和
  * 许可证下的限制。
  *
  * @author mwichary@google.com (Marcin Wichary)
  * 由 Christopher R. 修改。
  * 由 Hedda Zhang @ 2020.01 修改
  */

var gamepadSupport = {
    // Gamepad API 识别并映射到的一些典型按钮
    // 标准控件。 任何无关的按钮都会有更大的索引。
    TYPICAL_BUTTON_COUNT: 18,

    // Gamepad API 识别并映射到的一些典型轴
    // 标准控件。 任何无关的按钮都会有更大的索引。
    TYPICAL_AXIS_COUNT: 4,

    // 我们是否像 1999 年那样使用 requestAnimationFrameing。
    ticking: false,

    // 附加游戏手柄的规范列表，没有“孔”（总是
    // 从 [0] 开始）并在 Firefox 和 Chrome 之间统一。
    gamepads: [],

    // 记住上次检查时连接的游戏手柄； 在 Chrome 中使用
    // 确定游戏手柄何时连接或断开，因为没有
    // 事件被触发。
    prevRawGamepadTypes: [],

    // 游戏手柄状态的先前时间戳； 在 Chrome 中使用以不打扰
    // 如果没有任何变化（时间戳相同，则分析轮询数据
    // 和上次一样）。
    prevTimestamps: [],

    /**
      * 初始化对 Gamepad API 的支持。
      */
    init: function () {
        // 在撰写本文时，似乎无法检测到 Gamepad API 支持
        // 在 Firefox 中，因此我们需要在第三个子句中对其进行硬编码。
        // （前面两个子句是针对 Chrome 的。）
        if (!!navigator.getGamepads) {
            var gamepadSupportAvailable = !!navigator.getGamepads;
        } else {
            var gamepadSupportAvailable = !!navigator.webkitGetGamepads || !!navigator.webkitGamepads ||
                (navigator.userAgent.indexOf('Firefox/') != -1);
        }

        if (!gamepadSupportAvailable) {
            // 似乎 Gamepad API 不可用 ' 显示消息告诉
            // 关于它的访问者。
            tester.showNotSupported();
        } else {
            // Firefox 支持连接/断开连接事件，所以我们附加事件
            // 处理那些。
            window.addEventListener('gamepadconnected',
                gamepadSupport.onGamepadConnect, false);
            window.addEventListener('gamepaddisconnected',
                gamepadSupport.onGamepadDisconnect, false);

            // 由于 Chrome 只支持轮询，我们直接启动轮询循环
            // 离开。 对于 Firefox，我们只有在收到连接事件时才会这样做。
            if (!!navigator.getGamepads || !!navigator.webkitGamepads || !!navigator.webkitGetGamepads) {
                gamepadSupport.startPolling();
            }
        }
    },

    /**
      * 对正在连接的游戏手柄做出反应。 今天，这只会被执行
      * 在火狐上。
      */
    onGamepadConnect: function (event) {
        // 将新的游戏手柄添加到要照顾的游戏手柄列表中。
        gamepadSupport.gamepads.push(event.gamepad);

        // 要求测试人员更新屏幕以显示更多游戏手柄。
        tester.updateGamepads(gamepadSupport.gamepads);

        // 启动轮询循环来监控按钮的变化。
        gamepadSupport.startPolling();
    },

    // 这只会在 Firefox 上执行。
    onGamepadDisconnect: function (event) {
        // 从要监控的游戏手柄列表中删除游戏手柄。
        for (var i in gamepadSupport.gamepads) {
            if (gamepadSupport.gamepads[i].index == event.gamepad.index) {
                gamepadSupport.gamepads.splice(i, 1);
                break;
            }
        }

        // 如果没有游戏手柄，停止轮询循环。
        if (gamepadSupport.gamepads.length == 0) {
            gamepadSupport.stopPolling();
        }

        // 要求测试人员更新屏幕以移除游戏手柄。
        tester.updateGamepads(gamepadSupport.gamepads);
    },

    /**
      * 启动轮询循环以检查游戏手柄状态。
      */
    startPolling: function () {
        // 不要意外启动第二个循环，伙计。
        if (!gamepadSupport.ticking) {
            console.log(gamepadSupport.ticking) //false
            console.log(!gamepadSupport.ticking) //true

            gamepadSupport.ticking = true;
            gamepadSupport.tick();
        }
    },

    /**
      * 通过设置一个标志来停止轮询循环，这将阻止下一个
      * requestAnimationFrame() 被安排。
      */
    stopPolling: function () {
        gamepadSupport.ticking = false;
    },

    /**
      * 每个 requestAnimationFrame() 调用的函数。 轮询游戏手柄
      * 状态并安排另一个轮询。
      */
    tick: function () {
        gamepadSupport.pollStatus();
        gamepadSupport.scheduleNextTick();
    },

    scheduleNextTick: function () {
        // 如果我们还没有决定停止，则只安排下一帧
        // stopPolling() 之前。
        if (gamepadSupport.ticking) {
            if (window.requestAnimationFrame) {
                window.requestAnimationFrame(gamepadSupport.tick);
            } else if (window.mozRequestAnimationFrame) {
                window.mozRequestAnimationFrame(gamepadSupport.tick);
            } else if (window.webkitRequestAnimationFrame) {
                window.webkitRequestAnimationFrame(gamepadSupport.tick);
            }
            // 请注意缺少 setTimeout，因为所有浏览器都支持
            // Gamepad API 已经支持 requestAnimationFrame()。
        }
    },

    /**
      * 检查游戏手柄状态。 监控必要的数据和通知
      * 与之前状态的区别（Chrome/Firefox 的按钮，
      * Chrome 的新连接/断开连接）。 如果发现差异，询问
      * 相应地更新显示。 应该运行接近 60 帧/
      * 尽可能第二。
      */
    pollStatus: function () {
        // 轮询以查看游戏手柄是连接还是断开。 必要的
        // 仅在 Chrome 上。
        gamepadSupport.pollGamepads();

        for (var i in gamepadSupport.gamepads) {
            var gamepad = gamepadSupport.gamepads[i];

            // 如果当前时间戳与前一个时间戳相同，则不执行任何操作
            // 一，表示游戏手柄的状态没有改变。
            // 目前只有 Chrome 支持，所以首先检查
            // 确保如果时间戳为空，我们什么都不做
            // 或未定义。
            if (gamepad.timestamp &&
                (gamepad.timestamp == gamepadSupport.prevTimestamps[i])) {
                continue;
            }
            gamepadSupport.prevTimestamps[i] = gamepad.timestamp;
            gamepadSupport.updateDisplay(i);
        }
    },

    // 该函数只在Chrome上调用，尚不支持
    // 连接/断开事件，但需要你监控
    // 用于更改的数组。
    pollGamepads: function () {

        // 获取游戏手柄数组的第一个方法（函数调用）
        // 是最现代的，第二个是为了兼容
        // 稍旧的 Chrome 版本，但不是必须的
        // 很长时间。
        var rawGamepads =
            (navigator.getGamepads && navigator.getGamepads()) ||
            (navigator.webkitGetGamepads && navigator.webkitGetGamepads()) ||
            navigator.webkitGamepads;

        if (rawGamepads) {
            // 我们不想使用直接来自浏览器的 rawGamepad，
            // 因为它可能有“孔”（例如，如果您插入两个游戏手柄，然后
            // 拔掉第一个，剩下的将在索引 [1])。
            gamepadSupport.gamepads = [];
            gamepadSupport.gamepadsRaw = [];

            //var rawFixedGamepads = {};
            //for(var i = 0, ii = 0; i <= rawGamepads.length; i++){
            //    if (typeof rawGamepads[i] == "object" && rawGamepads[i].id.indexOf("(Vendor: b58e Product: 9e84)") !== -1) continue;
            //    rawFixedGamepads[ii] = rawGamepads[i];
            //    rawFixedGamepads.length = i;
            //    ii++;
            //}
            //console.log(rawFixedGamepads);
            //rawGamepads = rawFixedGamepads;


            // 我们只在检测到某些游戏手柄是新的时才刷新显示
            // 或移除； 我们通过将原始游戏手柄表条目与
            // '不明确的。'
            var gamepadsChanged = false;

            for (var i = 0; i < rawGamepads.length; i++) {
                if (typeof rawGamepads[i] != gamepadSupport.prevRawGamepadTypes[i]) {
                    gamepadsChanged = true;
                    gamepadSupport.prevRawGamepadTypes[i] = typeof rawGamepads[i];
                }
                //console.log(rawGamepads[i].id);
                //if (rawGamepads[i] == undefined || rawGamepads[i].id.indexOf("(Vendor: b58e Product: 9e84)") !== -1) continue;
                if (rawGamepads[i] && controllerRebinds != "" && typeof controllerRebinds.mapping != 'undefined' && controllerRebinds.mapping.length > 0) {
                    var remapObj = $.extend(true, {}, rawGamepads[i]);
                    for (var b = 0; b < remapObj.buttons.length; b++) {
                        remapObj.buttons[b] = $.extend({}, rawGamepads[i].buttons[b]);
                    }
                    for (var m = 0; m < controllerRebinds.mapping.length; m++) {
                        var bindmap = controllerRebinds.mapping[m];
                        var noMap = bindmap.disabled;
                        var tType = bindmap.targetType;
                        var tMap = bindmap.target;
                        if (tType == "buttons" && typeof remapObj[tType][tMap] == "undefined") {
                            remapObj[tType][tMap] = {};
                        }

                        function stickToButton(stickObj) {
                            //与函数名相反，它也把按钮变成了按钮
                            if (stickObj.choiceType == "buttons") {
                                return rawGamepads[i].buttons[stickObj.choice].value;
                            } else {
                                var axisVal = rawGamepads[i].axes[stickObj.choice];
                                switch (stickObj.choiceOperand) {
                                    case "+":
                                        return (axisVal > 0) ? axisVal : 0;
                                        break;
                                    case "-":
                                        return (axisVal < 0) ? Math.abs(axisVal) : 0;
                                        break;
                                    default:
                                        return 0;
                                }
                            }
                        }

                        function makeAxis(positiveAxis, negativeAxis) {
                            return positiveAxis - negativeAxis;
                        }

                        /***
                          * 这应该起到某种包装函数的作用，以允许更简单的生产方式
                          * 重新映射的值。 如果 bindmap 没有轴配置数据，则映射为
                          * 然后发送到stickToButton 函数，该函数然后产生适当的值。
                          *
                          * 当我必须实际考虑轴的时间时，这往往会变得有点棘手
                          * 坏了，因为我首先必须操作原始数据，然后返回正确的值，或者作为
                          * 按钮或轴。
                          * */
                        function bindWrapper(stickObj) {
                            if (tType == "dpad") {
                                dpadPOV(stickObj);
                                return;
                            }
                            if (typeof stickObj.axesConfig == "undefined") {
                                setMapping(stickObj, {});
                                return;
                            }
                            fixAxes(stickObj);
                        }

                        function choiceValue(mapObj) {
                            var value;
                            switch (mapObj.choiceType) {
                                case "":
                                    return choiceValue(mapObj.positive);
                                    break;
                                case "axes":
                                    value = rawGamepads[i].axes[mapObj.choice];
                                    break;
                                case "buttons":
                                    value = rawGamepads[i].buttons[mapObj.choice].value;
                                    break;
                                default:
                                    value = 0;
                            }
                            return value;
                        }

                        //要修复轴，我们假设所有修复都是触发器类型，并在需要时使用它来创建棒
                        function fixAxes(stickObj) {
                            var startValue = +stickObj.axesConfig.lowValue;
                            var endValue = +stickObj.axesConfig.highValue;

                            var isFlipped = (endValue < startValue);

                            if (isFlipped) {
                                var temp = startValue;
                                startValue = endValue;
                                endValue = temp;
                            }

                            var zeroOffset = startValue * -1;
                            var axisVal = choiceValue(stickObj);

                            //通过在当前值和结束值上加上偏移量，我们可以对输入进行归一化
                            var newValue = (axisVal + zeroOffset) / (endValue + zeroOffset);

                            //如果开始和结束交换，我们考虑它但从1中减去值
                            newValue = (isFlipped) ? (1 - newValue) : newValue;

                            switch (stickObj.axesConfig.type) {
                                case "trigger":
                                    break;
                                case "stick":
                                    newValue = (-1 + (newValue * 2));
                                    break;
                                default:
                                    setMapping(stickObj, {});
                                    return;
                            }
                            setMapping(stickObj, newValue);
                        }

                        function dpadPOV(stickObj) {
                            var up, down, left, right, upright, downright, downleft, upleft, value;
                            setMapping({ targetType: "buttons", target: 12 }, 0);
                            setMapping({ targetType: "buttons", target: 13 }, 0);
                            setMapping({ targetType: "buttons", target: 14 }, 0);
                            setMapping({ targetType: "buttons", target: 15 }, 0);
                            if (stickObj.disabled) return;
                            up = stickObj.positions.up;
                            down = stickObj.positions.down;
                            left = stickObj.positions.left;
                            right = stickObj.positions.right;
                            upright = stickObj.positions.upright;
                            downright = stickObj.positions.downright;
                            downleft = stickObj.positions.downleft;
                            upleft = stickObj.positions.upleft;
                            value = choiceValue(stickObj);
                            if (value == up) {
                                setMapping({ targetType: "buttons", target: 12 }, 1);
                            } else if (value == down) {
                                setMapping({ targetType: "buttons", target: 13 }, 1);
                            } else if (value == left) {
                                setMapping({ targetType: "buttons", target: 14 }, 1);
                            } else if (value == right) {
                                setMapping({ targetType: "buttons", target: 15 }, 1);
                            } else if (value == upright) {
                                setMapping({ targetType: "buttons", target: 12 }, 1);
                                setMapping({ targetType: "buttons", target: 15 }, 1);
                            } else if (value == downright) {
                                setMapping({ targetType: "buttons", target: 15 }, 1);
                                setMapping({ targetType: "buttons", target: 13 }, 1);
                            } else if (value == downleft) {
                                setMapping({ targetType: "buttons", target: 13 }, 1);
                                setMapping({ targetType: "buttons", target: 14 }, 1);
                            } else if (value == upleft) {
                                setMapping({ targetType: "buttons", target: 14 }, 1);
                                setMapping({ targetType: "buttons", target: 12 }, 1);
                            }
                        }

                        /***
                          * 这是为了轻松正确设置重新映射的项目，无论是按照定义的棒还是轴
                          * 通过绑定映射。
                          * */
                        function setMapping(stickObj, setValue) {
                            switch (typeof setValue) {
                                case "number":
                                case "Number":
                                    if (stickObj.targetType == "axes") {
                                        remapObj[stickObj.targetType][stickObj.target] = setValue;
                                    } else {
                                        remapObj[stickObj.targetType][stickObj.target].value = setValue;
                                    }
                                    break;
                                case "object":
                                case "Object":
                                    if (stickObj.targetType == "axes") {
                                        remapObj[stickObj.targetType][stickObj.target] = makeAxis(stickToButton(stickObj.positive), stickToButton(stickObj.negative));
                                    } else {
                                        remapObj[stickObj.targetType][stickObj.target].value = stickToButton(stickObj);
                                    }
                                    break;
                                default:
                            }
                        }

                        try {
                            if (noMap && tType != "dpad") {
                                setMapping(bindmap, 0);
                            } else {
                                bindWrapper(bindmap);
                            }
                        } catch (e) {
                            //console.log("ERROR IN MAPPING: ", e);
                        }
                    }
                    gamepadSupport.gamepads.push(remapObj);
                    gamepadSupport.gamepadsRaw.push(rawGamepads[i]);
                } else if (rawGamepads[i]) {
                    gamepadSupport.gamepads.push(rawGamepads[i]);
                    gamepadSupport.gamepadsRaw.push(rawGamepads[i]);
                }
            }

            // 要求测试者刷新游戏手柄的视觉表现
            // 屏幕上。
            if (gamepadsChanged) {
                tester.updateGamepads(gamepadSupport.gamepads);
            }
        }
    },

    // 用新状态调用测试器并要求它更新视觉
    // 给定游戏手柄的表示。
    updateDisplay: function (gamepadId) {
        var gamepad = gamepadSupport.gamepads[gamepadId];

        // 更新屏幕上的所有按钮（及其相应的标签）。
        tester.queueButton(gamepad.buttons[0], gamepadId, 'button-1');
        tester.queueButton(gamepad.buttons[1], gamepadId, 'button-2');
        tester.queueButton(gamepad.buttons[2], gamepadId, 'button-3');
        tester.queueButton(gamepad.buttons[3], gamepadId, 'button-4');

        tester.queueButton(gamepad.buttons[4], gamepadId, 'button-left-shoulder-top');
        tester.queueTrigger(gamepad.buttons[6], gamepadId, 'button-left-shoulder-bottom');
        tester.queueTriggerDigital(gamepad.buttons[6], gamepadId, 'button-left-shoulder-bottom-digital');
        tester.queueButton(gamepad.buttons[5], gamepadId, 'button-right-shoulder-top');
        tester.queueTrigger(gamepad.buttons[7], gamepadId, 'button-right-shoulder-bottom');
        tester.queueTriggerDigital(gamepad.buttons[7], gamepadId, 'button-right-shoulder-bottom-digital');

        tester.queueButton(gamepad.buttons[8], gamepadId, 'button-select');
        tester.queueButton(gamepad.buttons[9], gamepadId, 'button-start');

        tester.queueButton(gamepad.buttons[10], gamepadId, 'stick-1');
        tester.queueButton(gamepad.buttons[11], gamepadId, 'stick-2');

        tester.queueButton(gamepad.buttons[12], gamepadId, 'button-dpad-top');
        tester.queueButton(gamepad.buttons[13], gamepadId, 'button-dpad-bottom');
        tester.queueButton(gamepad.buttons[14], gamepadId, 'button-dpad-left');
        tester.queueButton(gamepad.buttons[15], gamepadId, 'button-dpad-right');
        tester.queueButton(gamepad.buttons[16], gamepadId, 'button-meta');
        tester.queueButton(gamepad.buttons[17], gamepadId, 'touch-pad');
        tester.queueStick(gamepad.buttons[12], 'up', gamepadId, 'arcade-stick');
        tester.queueStick(gamepad.buttons[13], 'down', gamepadId, 'arcade-stick');
        tester.queueStick(gamepad.buttons[14], 'left', gamepadId, 'arcade-stick');
        tester.queueStick(gamepad.buttons[15], 'right', gamepadId, 'arcade-stick');

        // 更新所有模拟棒。
        tester.queueAxis(gamepad.axes[0], gamepad.axes[1], gamepadId, 'stick-1');
        tester.queueAxis(gamepad.axes[2], gamepad.axes[3], gamepadId, 'stick-2');

        // 更新无关按钮。
        var extraButtonId = gamepadSupport.TYPICAL_BUTTON_COUNT;
        while (typeof gamepad.buttons[extraButtonId] != 'undefined') {
            //tester.queueButton(gamepad.buttons[extraButtonId], gamepadId,
            //    'extra-button-' + extraButtonId);

            extraButtonId++;
        }

        // 更新无关轴。
        var extraAxisId = gamepadSupport.TYPICAL_AXIS_COUNT;
        while (typeof gamepad.axes[extraAxisId] != 'undefined') {
            //tester.queueAxis(gamepad.axes[extraAxisId], gamepadId,
            //    'extra-axis-' + extraAxisId);

            extraAxisId++;
        }

    }
};