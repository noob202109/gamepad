﻿/**
* 版权所有 2012 Google Inc. 保留所有权利。
*
* 根据 Apache 许可证 2.0 版（“许可证”）获得许可；
* 除非遵守许可，否则您不得使用此文件。
* 您可以在以下网址获取许可证的副本
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* 除非适用法律要求或书面同意，否则软件
*根据许可分发是在“原样”基础上分发的，
* 不提供任何明示或暗示的保证或条件。
* 请参阅许可证以了解特定语言的管理权限和
* 许可证下的限制。
*
* @author mwichary@google.com (Marcin Wichary)
* 由 Hedda Zhang @ 2020.01 修改
*/

var tester = {
    // 如果数字以任何方式超过此值，我们将标签视为活动的
    // 并突出显示它。
    VISIBLE_THRESHOLD: 0.25,
    // 一根棍子可以在屏幕上移动多远。
    STICK_OFFSET: 22,

    // 是否应该启用棒状弯曲
    STICK_CURVING: 1,

    TRIGGER_DISPLAY_TYPE: 0,

    // 模拟按钮需要按下多深才能考虑按下按钮。

    // 对于像 Dualshock 3 这样的控制器，它有模拟按钮而不是数字按钮
    ANALOGUE_BUTTON_THRESHOLD: .25,
    // 模拟摇杆阈值
    ANALOGUE_STICK_THRESHOLD: .25,
    // 模拟按钮数字版本的阈值
    DIGITAL_THRESHOLD: .10,

    // 是否开始
    EVENT_LISTEN: 0,
    //被监控输入的游戏手柄ID
    MONITOR_ID: '',

    // 旋转限制
    ROTATE_BOUNDARY: 120,

    // 进行重新映射时要测试的快照对象
    SNAPSHOT: {},

    MONITOR_TYPE: "",

    // 应用户请求禁用监控的输入对象列表。 当讨厌的轴/按钮通过不断变化的值干扰正确捕获数据时，这会有所帮助。
    DISABLED_INPUTS: {},

    absDiff: function (a, b) {
        var result = a - b;
        result = Math.abs(result);
        return result;
    },

    ifDisabledExists: function (type, id, number) {
        if (id in tester.DISABLED_INPUTS) {
            if (type in tester.DISABLED_INPUTS[id]) {
                if (number in tester.DISABLED_INPUTS[id][type]) {
                    return true;
                }
            }
        }
        return false;
    },

    DELAY_TIME_MS: 0,

    updateQueue: new Queue(),
    processQueueCall: 0,

    init: function () {
        tester.updateGamepads();
    },

    /**
      * 告诉用户浏览器不支持 Gamepad API。
      */
    showNotSupported: function () {
        document.write('不支持的手柄类型！');
    },

    /**
      *更新屏幕上的游戏手柄，从
      * 模板。
      */
    updateGamepads: function (gamepads) {
        var els = document.querySelectorAll('.controller:not(.template)');
        for (var i = 0, el; el = els[i]; i++) {
            el.classList.add('disconnected');
        }
        var els2 = document.querySelectorAll('#player-base [value]');
        for (var i = 0, el; el = els2[i]; i++) {
            el.disabled = true;
        }
        var els3 = document.querySelectorAll('.raw-outputs:not(.template)');
        for (var i = 0, el; el = els3[i]; i++) {
            el.remove();
        }

        var padsConnected = false;
        tester.DISABLED_INPUTS = {};

        if (gamepads) {
            for (var i in gamepads) {
                var gamepad = gamepads[i];
                if (gamepad) {
                    var el2 = document.getElementById('player-base');
                    el2.querySelector('option[value="' + i + '"]').disabled = false;
                    var newRawMap = document.createElement('div');
                    newRawMap.innerHTML = document.querySelector('.raw-outputs.template').innerHTML;
                    newRawMap.id = 'gamepad-map-' + i;
                    newRawMap.className = 'raw-outputs';
                    for (var b in gamepad.buttons) {
                        var bEl = document.createElement('li');
                        bEl.setAttribute('data-shortname', 'B' + b);
                        bEl.setAttribute('data-name', 'button-' + b);
                        bEl.setAttribute('data-info', JSON.stringify({ id: i, type: "buttons", number: b }));
                        bEl.title = 'Button ' + b;
                        newRawMap.querySelector(".buttons").appendChild(bEl);
                    }
                    for (var a in gamepad.axes) {
                        var aEl = document.createElement('li');
                        aEl.setAttribute('data-shortname', 'Axis ' + a);
                        aEl.setAttribute('data-name', 'axis-' + a);
                        aEl.setAttribute('data-info', JSON.stringify({ id: i, type: "axes", number: a }));
                        aEl.title = 'Axis ' + a;
                        newRawMap.querySelector(".axes").appendChild(aEl);
                    }
                    var nameEl = document.createElement('h2');
                    nameEl.innerHTML = gamepad.id;
                    newRawMap.insertBefore(nameEl, newRawMap.firstChild);
                    document.querySelector('#output-display').appendChild(newRawMap);

                    var el = document.getElementById('gamepad-' + i);
                    el.querySelector('.quadrant').classList.add('p' + i);
                    el.classList.remove('disconnected');

                    padsConnected = true;
                }
            }
        }
    },

    queueButton: function (value, gamepadId, id) {
        //复制值...因为引用
        var newVal = jQuery.extend({}, value);

        tester.updateQueue.enqueue([Date.now() + tester.DELAY_TIME_MS, tester.updateButton, [newVal, gamepadId, id]]);
        tester.processQueue();
    },

    queueStick: function (value, className, gamepadId, id) {
        //需要复制值吗？ 不知道
        var newVal = jQuery.extend({}, value);

        tester.updateQueue.enqueue([Date.now() + tester.DELAY_TIME_MS, tester.updateStick, [newVal, className, gamepadId, id]]);
        tester.processQueue();
    },

    queueTrigger: function (value, gamepadId, id) {
        //需要复制值吗？ 不知道
        var newVal = jQuery.extend({}, value);

        tester.updateQueue.enqueue([Date.now() + tester.DELAY_TIME_MS, tester.updateTrigger, [newVal, gamepadId, id]]);
        tester.processQueue();
    },

    queueTriggerDigital: function (value, gamepadId, id) {
        //复制值...因为引用
        var newVal = jQuery.extend({}, value);

        tester.updateQueue.enqueue([Date.now() + tester.DELAY_TIME_MS, tester.updateTriggerDigital, [newVal, gamepadId, id]]);
        tester.processQueue();
    },

    queueAxis: function (value, valueV, gamepadId, stickId) {
        //不需要复制值？
        tester.updateQueue.enqueue([Date.now() + tester.DELAY_TIME_MS, tester.updateAxis, [value, valueV, gamepadId, stickId]]);
        tester.processQueue();
    },

    /**
     * 更新屏幕上的给定按钮。
     */
    updateButton: function (value, gamepadId, id) {
        var gamepadEl = document.querySelector('#gamepad-' + gamepadId);
        var newValue = value;
        if (typeof value == 'object') {
            var newValue = value.value;
        }

        // 直观地更新按钮
        var buttonEl = gamepadEl.querySelector('[data-name="' + id + '"]');
        if (buttonEl) { // 多余的按钮只有一个标签。
            if (newValue > tester.ANALOGUE_BUTTON_THRESHOLD) {
                buttonEl.classList.add('pressed');
            } else {
                buttonEl.classList.remove('pressed');
            }
        }

    },

    /**
     * 使用提供的名称更新战斗棒
     */
    updateStick: function (value, className, gamepadId, id) {
        var gamepadEl = document.querySelector('#gamepad-' + gamepadId);
        var newValue = value;
        if (typeof value == 'object') {
            var newValue = value.value;
        }

        // 直观地更新按钮。
        var buttonEl = gamepadEl.querySelector('[data-name="' + id + '"]');
        if (buttonEl) { // 多余的按钮只有一个标签。
            if (newValue > tester.ANALOGUE_BUTTON_THRESHOLD) {
                buttonEl.classList.add(className);
            } else {
                buttonEl.classList.remove(className);
            }
        }

    },

    updateTrigger: function (value, gamepadId, id) {
        var gamepadEl = document.querySelector('#gamepad-' + gamepadId);
        var newValue = value;
        if (typeof value == 'object') {
            var newValue = value.value;
        }

        // 直观地更新按钮。
        var triggerEl = gamepadEl.querySelector('[data-name="' + id + '"]');
        if (triggerEl) {
            if (tester.TRIGGER_DISPLAY_TYPE == 1) {
                triggerEl.style.opacity = 1;
                var insetValue = (((-1 + newValue) * -1) * 100) - 0.00001;
                //var insetValue = (((-1 + newValue) * -1) * 100);
                insetValue = insetValue.toString() + "%";
                triggerEl.style.webkitClipPath = "inset(" + insetValue + " 0px 0px 0pc)";
                triggerEl.style.mozClipPath = "inset(" + insetValue + " 0px 0px 0pc)";
                triggerEl.style.clipPath = "inset(" + insetValue + " 0px 0px 0pc)";
            } else {
                triggerEl.style.opacity = newValue;
            }
        }

    },

    /**
      * 在屏幕上以二进制方式更新触发器。
      */
    updateTriggerDigital: function (value, gamepadId, id) {
        var gamepadEl = document.querySelector('#gamepad-' + gamepadId);
        var newValue = value;
        if (typeof value == 'object') {
            var newValue = value.value;
        }

        // 直观地更新按钮。
        var buttonEl = gamepadEl.querySelector('[data-name="' + id + '"]');
        if (buttonEl) { // 无关按钮只有一个标签。
            if (newValue > tester.DIGITAL_THRESHOLD) {
                buttonEl.classList.add('pressed');
            } else {
                buttonEl.classList.remove('pressed');
            }
        }

    },

    /**
      *更新屏幕上给定的模拟棒。
      */
    updateAxis: function (value, valueV, gamepadId, stickId) {
        var gamepadEl = document.querySelector('#gamepad-' + gamepadId);

        function lineDistance(point1, point2) {
            var xs = point1 - 0;
            var ys = point2 - 0;

            xs = xs * xs;
            ys = ys * ys;

            return Math.sqrt(xs + ys);
        }

        // 直观地更新棒。
        var stickEl = gamepadEl.querySelector('[data-name="' + stickId + '"]');
        if (stickEl) { // 无关的棍子只有一个标签。
            if (lineDistance(value, valueV) >= tester.ANALOGUE_STICK_THRESHOLD) {
                var offsetValH = value * tester.STICK_OFFSET;
                var offsetValV = valueV * tester.STICK_OFFSET;
            } else {
                var offsetValH = 0;
                var offsetValV = 0;
            }
            stickEl.style.marginLeft = offsetValH + 'px';
            stickEl.style.marginTop = offsetValV + 'px';
            if (tester.STICK_CURVING) {
                stickEl.style.transform = 'rotateX(' + offsetValV * -1 + 'deg) rotateY(' + offsetValH + 'deg)';
            }
        }

        // 更新摇杆横向旋转
        var stickRotEL = gamepadEl.querySelector('[data-name="' + stickId + '-wheel"]');
        if (stickRotEL) {
            if (lineDistance(value, valueV) >= tester.ANALOGUE_STICK_THRESHOLD) {
                var rotValH = value;
            } else {
                var rotValH = 0;
            }
            stickRotEL.style.transform = 'rotate(' + rotValH * tester.ROTATE_BOUNDARY + 'deg)';
        }

    },

    /**
      *更新屏幕上的给定按钮。
      */
    updateRawButton: function (value, gamepadId, buttonId) {
        var gamepadEl = document.querySelector('#gamepad-map-' + gamepadId);
        var newValue = value;
        if (typeof value == 'object') {
            var newValue = value.value;
        }

        // 直观地更新按钮。
        var buttonEl = gamepadEl.querySelector('[data-name="button-' + buttonId + '"]');
        var mapConfig = document.querySelectorAll("#mapping-config button");
        if (buttonEl) { // 无关按钮只有一个标签。
            buttonEl.innerHTML = newValue.toFixed(2);
            buttonEl.style.opacity = .6 + (newValue * .4);
            if (tester.EVENT_LISTEN) {
                if (tester.MONITOR_ID == gamepadId && !tester.ifDisabledExists("buttons", gamepadId, buttonId)) {
                    var gpEvent = new CustomEvent('GamepadPressed', {
                        detail: {
                            gamepad: gamepadId,
                            type: "buttons",
                            typeName: "Button",
                            fullname: "Button " + buttonId,
                            value: newValue,
                            config: {
                                choiceType: "buttons",
                                choice: buttonId
                            }
                        },
                        bubbles: true
                    });
                    if (tester.MONITOR_TYPE == "remapping" && tester.absDiff(tester.SNAPSHOT.buttons[buttonId].value, newValue) > tester.ANALOGUE_BUTTON_THRESHOLD || tester.MONITOR_TYPE == "value") {
                        for (var i = 0; i < mapConfig.length; i++) {
                            mapConfig[i].dispatchEvent(gpEvent);
                        }
                    }
                }
            }
        }

    },
    /**
      * 更新屏幕上给定的轴值。
      */
    updateRawAxis: function (value, gamepadId, axisId) {
        var gamepadEl = document.querySelector('#gamepad-map-' + gamepadId);
        var newValue = value;
        if (typeof value == 'object') {
            var newValue = value.value;
        }

        // 直观地更新按钮。
        var axisEl = gamepadEl.querySelector('[data-name="axis-' + axisId + '"]');
        var mapConfig = document.querySelectorAll("#mapping-config button");
        if (axisEl) { // 无关按钮只有一个标签。
            axisEl.innerHTML = newValue.toFixed(10);
            axisEl.style.opacity = .6 + (Math.abs(newValue) * .4);
            if (tester.EVENT_LISTEN) {
                if (tester.MONITOR_ID == gamepadId && !tester.ifDisabledExists("axes", gamepadId, axisId)) {
                    var axisOp = (newValue > 0) ? "+" : "-";
                    var gpEvent = new CustomEvent('GamepadPressed', {
                        detail: {
                            gamepad: +gamepadId,
                            type: "axes",
                            typeName: "Axis",
                            fullname: "Axis " + axisId + " " + axisOp,
                            value: newValue,
                            config: {
                                choiceOperand: axisOp,
                                choiceType: "axes",
                                choice: axisId
                            }
                        },
                        bubbles: true
                    });
                    if (tester.MONITOR_TYPE == "remapping" && tester.absDiff(tester.SNAPSHOT.axes[axisId], newValue) > tester.ANALOGUE_BUTTON_THRESHOLD || tester.MONITOR_TYPE == "value") {
                        for (var i = 0; i < mapConfig.length; i++) {
                            mapConfig[i].dispatchEvent(gpEvent);
                        }
                    }
                }
            }
        }
    },

    processQueue: function () {
        var myProcessQueueCall = tester.processQueueCall + 1;
        tester.processQueueCall = myProcessQueueCall;
        while (tester.updateQueue != undefined && tester.updateQueue.peek() != undefined && tester.updateQueue.peek()[0] <= Date.now()) {
            var elem = tester.updateQueue.dequeue();
            var vars = elem[2];
            if (elem[1] == tester.updateStick) {
                tester.updateStick(vars[0], vars[1], vars[2], vars[3])
            } else if (elem[1] == tester.updateAxis) {
                tester.updateAxis(vars[0], vars[1], vars[2], vars[3]);
            } else {
                elem[1](vars[0], vars[1], vars[2]);
            }
        }
    }
};
